# MDGATE


python 3.7



Run main.py to Run MDGATE
