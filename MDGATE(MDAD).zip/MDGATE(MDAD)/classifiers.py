import tensorflow as tf
from tensorflow.keras import layers
import tensorflow._api.v2.compat.v1 as tf

from data_preprocess import prepare_graph_data, parse_args
from gate_trainer import GATETrainer

def get_gate_feature(adj, features, epochs, l):
    args = parse_args(epochs=epochs,l=l)
    feature_dim = features.shape[1]
    args.hidden_dims = [feature_dim] + args.hidden_dims

    G, S, R = prepare_graph_data(adj)
    gate_trainer = GATETrainer(args)
    gate_trainer(G, features, S, R)
    embeddings, attention = gate_trainer.infer(G, features, S, R)
    tf.reset_default_graph()
    return embeddings


def get_dnn():
    model = tf.keras.Sequential(
        [
            layers.Dropout(rate=0.1),
            layers.BatchNormalization(),
            layers.Dense(128, activation="relu"),
            layers.BatchNormalization(),
            layers.Dropout(rate=0.1),
            layers.Dense(64, activation="relu"),
            layers.BatchNormalization(),
            layers.Dropout(rate=0.1),
            layers.Dense(32, activation="relu"),
            layers.BatchNormalization(),
            layers.Dropout(rate=0.1),
            layers.Dense(1, activation="sigmoid")
        ]
    )
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=1e-4),
        loss=tf.keras.losses.BinaryCrossentropy(),
        metrics=['accuracy','AUC'],
    )

    return model