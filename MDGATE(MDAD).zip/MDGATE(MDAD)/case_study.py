import pandas as pd

import classifiers
import gate
from data_generate import *
from data_preprocess import single_generate_graph_adj_and_feature
from sim_processing import get_syn_sim, sim_thresholding, GIP_kernel

# get sim matrix and association
Mic_sim_matrix = pd.read_csv("mydata/microbe_sim.csv", index_col=0, dtype=np.float32).to_numpy()
Dru_sim_matrix = pd.read_csv("mydata/drug_sim.csv", index_col=0, dtype=np.float32).to_numpy()
association = pd.read_csv("mydata/microbe-drug_adj.csv", index_col=0).to_numpy()

def get_syn_sim_Mic_Dru(A,Mic_sim, Dru_sim, k1, k2):
    drug_sim1 = Dru_sim
    Microbe_sim1 = Mic_sim

    GIP_c_sim = GIP_kernel(A)
    GIP_d_sim = GIP_kernel(A.T)
    # miRNA_sim1 = GIP_m_sim
    m1 = new_normalization(Microbe_sim1)
    m2 = new_normalization(GIP_c_sim)

    Sm_1 = KNN_kernel(Microbe_sim1, k1)
    Sm_2 = KNN_kernel(GIP_c_sim, k1)
    Pm = MIC_updating(Sm_1, Sm_2, m1, m2)
    Pm_final = (Pm + Pm.T) / 2

    d1 = new_normalization(drug_sim1)
    d2 = new_normalization(GIP_d_sim)

    Sd_1 = KNN_kernel(drug_sim1, k2)
    Sd_2 = KNN_kernel(GIP_d_sim, k2)
    Pd = DRUG_updating(Sd_1, Sd_2, d1, d2)
    Pd_final = (Pd + Pd.T) / 2

    return Pm_final, Pd_final


def new_normalization(w):
    m = w.shape[0]
    p = np.zeros([m, m])
    for i in range(m):
        for j in range(m):
            if i == j:
                p[i][j] = 1 / 2
            elif np.sum(w[i, :]) - w[i, i] > 0:
                p[i][j] = w[i, j] / (2 * (np.sum(w[i, :]) - w[i, i]))
    return p


def KNN_kernel(S, k):
    n = S.shape[0]
    S_knn = np.zeros([n, n])
    for i in range(n):
        sort_index = np.argsort(S[i, :])
        for j in sort_index[n - k:n]:
            if np.sum(S[i, sort_index[n - k:n]]) > 0:
                S_knn[i][j] = S[i][j] / (np.sum(S[i, sort_index[n - k:n]]))
    return S_knn


def MIC_updating(S1, S2, P1, P2):
    P = (P1 + P2) / 2
    dif = 1
    while dif > 0.0000001:
        P111 = np.dot(np.dot(S1, P2), S1.T)
        P111 = new_normalization(P111)
        P222 = np.dot(np.dot(S2, P1), S2.T)
        P222 = new_normalization(P222)
        P1 = P111
        P2 = P222
        P_New = (P1 + P2) / 2
        dif = np.linalg.norm(P_New - P) / np.linalg.norm(P)
        P = P_New
    return P


def DRUG_updating(S1, S2, P1, P2):
    P = (P1 + P2) / 2
    dif = 1
    while dif > 0.0000001:
        P111 = np.dot(np.dot(S1, P2), S1.T)
        P111 = new_normalization(P111)
        P222 = np.dot(np.dot(S2, P1), S2.T)
        P222 = new_normalization(P222)
        P1 = P111
        P2 = P222
        P_New = (P1 + P2) / 2
        dif = np.linalg.norm(P_New - P) / np.linalg.norm(P)
        P = P_New
    return P


# ====================================================================
def skf_normalization(w):
    row_sum = np.sum(w, axis=0)
    p = (w / row_sum).T
    return p


def skf(A, Mic_sim, Dru_sim, k1, k2):
    drug_sim1 = Dru_sim
    Microbe_sim1 = Mic_sim

    GIP_c_sim = GIP_kernel(A)
    GIP_d_sim = GIP_kernel(A.T)

    m1 = skf_normalization(Microbe_sim1)
    m2 = skf_normalization(GIP_c_sim)

    Sm_1 = KNN_kernel(Microbe_sim1, k1)
    Sm_2 = KNN_kernel(GIP_c_sim, k1)
    Pm = skf_updating(Sm_1, Sm_2, m1, m2, 0.1)
    nei_weight1 = neighborhood_Com(Pm, k1)
    Pm_final = Pm * nei_weight1

    d1 = skf_normalization(drug_sim1 )
    d2 = skf_normalization(GIP_d_sim)

    Sd_1 = KNN_kernel(drug_sim1 , k2)
    Sd_2 = KNN_kernel(GIP_d_sim, k2)
    Pd = skf_updating(Sd_1, Sd_2, d1, d2, 0.1)
    nei_weight2 = neighborhood_Com(Pd, k2)
    Pd_final = Pd * nei_weight2

    return Pm_final, Pd_final


def skf_updating(S1, S2, P1, P2, alpha):
    P = (P1 + P2) / 2
    dif = 1
    while dif > 0.0000001:
        P111 = alpha * np.dot(np.dot(S1, P2), S1.T) + (1 - alpha) * P2
        P111 = new_normalization(P111)
        P222 = alpha * np.dot(np.dot(S2, P1), S2.T) + (1 - alpha) * P1
        P222 = new_normalization(P222)
        P1 = P111
        P2 = P222
        P_New = (P1 + P2) / 2
        dif = np.linalg.norm(P_New - P) / np.linalg.norm(P)
        P = P_New
    return P


def neighborhood_Com(sim, k):
    weight = np.zeros(sim.shape)

    for i in range(sim.shape[0]):
        iu = sim[i, :]
        iu_list = np.abs(np.sort(-iu))
        iu_nearest_list_end = iu_list[k - 1]
        for j in range(sim.shape[1]):
            ju = sim[:, j]
            ju_list = np.abs(np.sort(-ju))
            ju_nearest_list_end = ju_list[k - 1]

            if sim[i, j] >= iu_nearest_list_end and sim[i, j] >= ju_nearest_list_end:
                weight[i, j] = 1
                weight[j, i] = 1
            elif sim[i, j] < iu_nearest_list_end and sim[i, j] < ju_nearest_list_end:
                weight[i, j] = 0
                weight[j, i] = 0
            else:
                weight[i, j] = 0.5
                weight[j, i] = 0.5

    return weight


def get_all_pred_samples(conjunction):
    pred=[]
    for index in range(conjunction.shape[0]):
        for col in range(conjunction.shape[1]):
                pred.append([index, col, 1])
    pred=np.array(pred)
    return pred


# super_parameter
latent_dims = [128]
n_splits = 10
classifier_epochs = 50
c_threshold = 0.7 # generate subgraph
d_threshold = 0.6  # generate subgraph

pred_score_matrix=np.zeros((173,1373))
for index in range(10):
    print(f"{index}-th prediction start...")

    samples = get_all_samples(association)



    print("start: feature extraction")

    c_sim, d_sim = get_syn_sim(association, Mic_sim_matrix, Dru_sim_matrix, mode=1)

    # GATE
    c_network = sim_thresholding(c_sim, c_threshold)
    d_network = sim_thresholding(d_sim, d_threshold)
    c_adj, c_features = single_generate_graph_adj_and_feature(c_network, association)
    d_adj, d_features = single_generate_graph_adj_and_feature(d_network, association.T)
    c_embeddings = classifiers.get_gate_feature(c_adj, c_features, 200, 1)
    d_embeddings = classifiers.get_gate_feature(d_adj, d_features, 200, 1)

    features = [c_embeddings, d_embeddings]
    feature, label = generate_f(samples, features)

    model = classifiers.get_dnn()


    print("start model fit")
    history = model.fit(feature, label, batch_size=64,
                        epochs=classifier_epochs, verbose=0)

    print("start prediction")
    pred_samples = get_all_pred_samples(association)
    pred_feature, pred_label = generate_f(pred_samples, features)
    pred_score = model.predict(pred_feature)[:, 0]
    for i in range(len(pred_score)):
        pred_score_matrix[pred_samples[i,0], pred_samples[i,1]]+=pred_score[i]

pred_score=pd.DataFrame(pred_score_matrix/10)
pred_score.to_csv("mydata/pred_results.csv")
pass